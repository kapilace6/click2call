const axios = require("axios");
const base64 = require("base-64");
const cheerio = require("cheerio");

exports = {
  events: [
    { event: "onTicketUpdate", callback: "onTicketUpdateHandler" },
    { event: "onTicketCreate", callback: "onTicketCreateHandler" }
  ],

  onTicketCreateHandler: function(args) {
    console.log("Logging onTicketCreate data", JSON.stringify(args));
    getTicket(args.data.ticket.id, args.iparams).then(function(response) {
      var ticketData = response.data;
      var patientData = args.data.requester.mobile || args.data.requester.phone;
      if (patientData) {
        // create a link
        const $ = cheerio.load(
          `<br/><a id="calllink" href="${args.iparams.url}&requester=${patientData}&state=${ticketData.custom_fields.cf_state}">${args.iparams.hyperlinktext}</a>`
        );
        var html = $.html();
        console.log("Log: patientData: " +  patientData + ", html: " + html);
        
        // Append the html to the existing description
        putTicket(
          args.data.ticket.id,
          {
            description: ticketData.description + html
          },
          args.iparams
        )
          .then(function(response) {
            console.log("Log: response", response.data);
          })
          .catch(function(err) {
            console.error("Log: err", err);
          });
      } else {
        console.log("Patient number is not there");
      }
    });
  },
  // args is a JSON block containing the payload information.
  // args['iparam'] will contain the installation parameter values.
  onTicketUpdateHandler: function(args) {
    console.log("Logging onTicketUpdate data: ", JSON.stringify(args.data));
    if (
      args.data.ticket.changes.responder_id &&
      args.data.ticket.changes.responder_id[1] !== null
    ) {
      // Proceed with the building of the url
      // get agent's mobile
      Promise.all([
        getAgent(args.data.ticket.changes.responder_id[1], args.iparams),
        getTicket(args.data.ticket.id, args.iparams)
      ]).then(function(results) {
        var agent = results[0].data;
        var ticket = results[1].data;

        var agentmobile = agent.contact.mobile || agent.contact.phone;
        
        const $ = cheerio.load(ticket.description);
        var patientData = args.data.requester.mobile || args.data.requester.phone;
        console.log("Log: agentmobile: " + agentmobile + ", patientData: " + patientData);

        $("#calllink").attr(
          "href",
          `${args.iparams.url}&requester=${patientData}&state=${ticket.custom_fields.cf_state}&attendee=${agentmobile}`
        );
        var html = $.html();

        var allowedgroups = args.iparams.allowedgroups.split(',').map(Number);
        if(allowedgroups.includes(args.data.ticket.group_id)) {
          const $p = cheerio.load(
            `<br/><a id="prescription" href="${args.iparams.prescriptionredirecturl}&requester=${patientData}&attendee=${agentmobile}&state=${ticket.custom_fields.cf_state}">${args.iparams.prescriptionlabel}</a>`
          );
          html = html + $p.html();
          console.log("Log: html", html);
        }

        putTicket(
          args.data.ticket.id,
          {
            description: html
          },
          args.iparams
        )
          .then(function(response) {
            console.log("Log: response", response.data);
          })
          .catch(function(err) {
            console.error("Log: err", err);
          });
      });
    }
  }
};

function getAgent(id, iparam) {
  setHeaders(iparam);
  return axios.get(`https://${iparam.fdurl}.freshdesk.com/api/v2/agents/${id}`);
}

function getTicket(ticketId, iparam) {
  setHeaders(iparam);
  return axios.get(
    `https://${iparam.fdurl}.freshdesk.com/api/v2/tickets/${ticketId}`
  );
}

function putTicket(ticketId, payload, iparam) {
  setHeaders(iparam);
  return axios.put(
    `https://${iparam.fdurl}.freshdesk.com/api/v2/tickets/${ticketId}`,
    payload
  );
}

function setHeaders(iparam) {
  axios.defaults.headers.common["Authorization"] = base64.encode(
    iparam.fdapikey + ":*"
  );
}
